from pathlib import Path
import sys

try:
    import yaml
except Exception as exc:
    print(f"YAML parser unavailable: {exc}")
    sys.exit(2)

root = Path(__file__).resolve().parent
compose = yaml.safe_load((root / "docker-compose.yml").read_text(encoding="utf-8"))
services = compose.get("services", {})
expected = {"app", "nginx", "postgres"}
actual = set(services)
if actual != expected:
    raise SystemExit(f"Unexpected services: {actual}; expected {expected}")

if services["nginx"]["ports"] != ["127.0.0.1:8080:80"]:
    raise SystemExit("nginx must publish only 127.0.0.1:8080:80")
if services["postgres"]["ports"] != ["127.0.0.1:5432:5432"]:
    raise SystemExit("postgres must publish only 127.0.0.1:5432:5432")
if "ports" in services["app"]:
    raise SystemExit("PHP-FPM must not be published to the host")
if "pgdata" not in compose.get("volumes", {}):
    raise SystemExit("pgdata volume is missing")
if "healthcheck" not in services["postgres"]:
    raise SystemExit("postgres healthcheck is missing")

nginx_conf = (root / "docker/nginx/default.conf").read_text(encoding="utf-8")
for required in ("root /var/www/html/web;", "fastcgi_pass app:9000;", "try_files $uri $uri/ /index.php?$query_string;"):
    if required not in nginx_conf:
        raise SystemExit(f"nginx directive is missing: {required}")

php_dockerfile = (root / "docker/php/Dockerfile").read_text(encoding="utf-8")
for required in ("php:8.4-fpm-bookworm", "pdo_pgsql", "www.conf"):
    if required not in php_dockerfile:
        raise SystemExit(f"PHP Dockerfile entry is missing: {required}")

fpm_pool = (root / "docker/php/www.conf").read_text(encoding="utf-8")
for required in ("user = appuser", "group = appuser", "listen = 9000"):
    if required not in fpm_pool:
        raise SystemExit(f"PHP-FPM pool entry is missing: {required}")

print("OK: Compose has app, nginx, and postgres only")
print("OK: nginx and postgres are bound to loopback")
print("OK: PHP-FPM has no host port")
print("OK: PostgreSQL named volume and healthcheck are present")
print("OK: nginx FastCGI routing points to app:9000")
print("OK: PHP-FPM image contains pdo_pgsql and custom pool")
