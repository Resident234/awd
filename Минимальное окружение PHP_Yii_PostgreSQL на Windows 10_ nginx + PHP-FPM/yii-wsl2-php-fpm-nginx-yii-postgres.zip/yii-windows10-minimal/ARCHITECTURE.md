# Минимальная архитектура

Для текущего этапа используются:

- WSL 2 и Ubuntu как Linux-окружение на Windows 10;
- Docker Desktop с WSL 2 backend;
- Docker Compose;
- nginx как HTTP-входная точка;
- PHP 8.4-FPM с Composer и расширением `pdo_pgsql`;
- Yii 2 basic application;
- PostgreSQL 16.

Redis, Memcached, Jenkins, Selenium и Phing пока не включаются.

Compose содержит три сервиса:

- `nginx` — принимает запросы на `http://localhost:8080`, раздаёт статические файлы из `app/web` и передаёт PHP-запросы в `app:9000`;
- `app` — PHP-FPM/Yii; исходный код монтируется из `./app`, порт PHP-FPM наружу не публикуется;
- `postgres` — PostgreSQL 16 с named volume `pgdata`, наружу опционально публикуется на `127.0.0.1:5432` для локальных клиентов.

Nginx и PHP-FPM находятся в одной Compose-сети. В nginx upstream указывается `app:9000`, а не `localhost:9000`. Yii подключается к PostgreSQL по адресу `postgres:5432`, а не через `localhost`.
