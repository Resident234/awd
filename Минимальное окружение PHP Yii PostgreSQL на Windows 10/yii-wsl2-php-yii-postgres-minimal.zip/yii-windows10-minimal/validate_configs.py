from pathlib import Path
import sys

try:
    import yaml
except Exception as exc:
    print(f"YAML parser unavailable: {exc}")
    sys.exit(2)

root = Path(__file__).resolve().parent
compose = yaml.safe_load((root / "docker-compose.yml").read_text(encoding="utf-8"))
services = compose.get("services", {})
expected = {"app", "postgres"}
actual = set(services)
if actual != expected:
    raise SystemExit(f"Unexpected services: {actual}; expected {expected}")

if services["app"]["ports"] != ["127.0.0.1:8080:8080"]:
    raise SystemExit("app must publish only 127.0.0.1:8080:8080")
if services["postgres"]["ports"] != ["127.0.0.1:5432:5432"]:
    raise SystemExit("postgres must publish only 127.0.0.1:5432:5432")
if "pgdata" not in compose.get("volumes", {}):
    raise SystemExit("pgdata volume is missing")
if "healthcheck" not in services["postgres"]:
    raise SystemExit("postgres healthcheck is missing")

print("OK: minimal Compose has only app and postgres")
print("OK: app and postgres are bound to loopback")
print("OK: PostgreSQL named volume and healthcheck are present")
