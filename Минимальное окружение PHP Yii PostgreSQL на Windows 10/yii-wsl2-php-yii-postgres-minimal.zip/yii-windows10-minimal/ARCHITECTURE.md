# Минимальная архитектура

Для текущего этапа используются только:

- WSL 2 и Ubuntu как Linux-окружение на Windows 10;
- Docker Desktop с WSL 2 backend;
- Docker Compose;
- PHP 8.4 CLI с Composer и расширением `pdo_pgsql`;
- Yii 2 basic application;
- PostgreSQL 16.

Nginx, Redis, Memcached, Jenkins, Selenium и Phing не включаются.

Чтобы не добавлять nginx раньше времени, приложение обслуживается встроенным development-сервером PHP: `php -S 0.0.0.0:8080 -t web web/index.php`. Этот сервер предназначен только для локальной разработки, не для production.

Compose содержит два сервиса:

- `app` — PHP/Yii, исходный код монтируется из `./app`, наружу публикуется только `127.0.0.1:8080`;
- `postgres` — PostgreSQL 16 с named volume `pgdata`, наружу опционально публикуется `127.0.0.1:5432` для pgAdmin/psql на хосте.

Внутри Compose приложение подключается к базе по имени сервиса `postgres`, а не через `localhost`.
