<?php

declare(strict_types=1);

$url = rtrim(getenv('SELENIUM_URL') ?: 'http://selenium:4444', '/') . '/status';
$deadline = time() + 180;

while (time() < $deadline) {
    $context = stream_context_create([
        'http' => [
            'timeout' => 5,
            'ignore_errors' => true,
        ],
    ]);

    $body = @file_get_contents($url, false, $context);
    if ($body !== false) {
        $status = json_decode($body, true);
        if (is_array($status) && (($status['value']['ready'] ?? false) === true)) {
            fwrite(STDOUT, "Selenium is ready at {$url}\n");
            exit(0);
        }
    }

    sleep(3);
}

fwrite(STDERR, "Selenium did not become ready within 180 seconds: {$url}\n");
exit(1);
