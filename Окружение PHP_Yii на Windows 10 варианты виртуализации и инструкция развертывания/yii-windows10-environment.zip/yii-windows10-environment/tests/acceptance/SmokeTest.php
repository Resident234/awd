<?php

declare(strict_types=1);

namespace tests\acceptance;

use Facebook\WebDriver\Chrome\ChromeOptions;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use PHPUnit\Framework\TestCase;

final class SmokeTest extends TestCase
{
    public function testHomePageIsReachableInChrome(): void
    {
        if (getenv('RUN_ACCEPTANCE') !== '1') {
            self::markTestSkipped('Set RUN_ACCEPTANCE=1 to run browser tests.');
        }

        $seleniumUrl = rtrim(getenv('SELENIUM_URL') ?: 'http://selenium:4444', '/') . '/wd/hub';
        $appUrl = rtrim(getenv('APP_URL') ?: 'http://nginx', '/');

        $options = new ChromeOptions();
        $options->addArguments([
            '--headless=new',
            '--no-sandbox',
            '--disable-dev-shm-usage',
            '--window-size=1440,900',
        ]);

        $driver = RemoteWebDriver::create($seleniumUrl, $options);

        try {
            $driver->get($appUrl);
            self::assertNotSame('', trim($driver->getTitle()));
            self::assertStringNotContainsString('502 Bad Gateway', $driver->getPageSource());
        } finally {
            $driver->quit();
        }
    }
}
