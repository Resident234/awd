<?php

declare(strict_types=1);

function ok(string $name): void
{
    fwrite(STDOUT, "OK  {$name}\n");
}

function fail(string $name, Throwable $e): never
{
    fwrite(STDERR, "ERR {$name}: {$e->getMessage()}\n");
    exit(1);
}

try {
    $dsn = getenv('DB_DSN') ?: 'pgsql:host=postgres;port=5432;dbname=yii_dev';
    $pdo = new PDO($dsn, getenv('DB_USERNAME') ?: 'yii', getenv('DB_PASSWORD') ?: 'change-me-now', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $pdo->query('SELECT 1');
    ok('PostgreSQL');
} catch (Throwable $e) {
    fail('PostgreSQL', $e);
}

try {
    $redis = new Redis();
    $redis->connect(getenv('REDIS_HOST') ?: 'redis', (int) (getenv('REDIS_PORT') ?: 6379), 5);
    $redis->auth(getenv('REDIS_PASSWORD') ?: 'change-me-redis');
    if ($redis->ping() !== true && $redis->ping() !== '+PONG') {
        throw new RuntimeException('PING did not return PONG');
    }
    ok('Redis');
} catch (Throwable $e) {
    fail('Redis', $e);
}

try {
    $memcached = new Memcached();
    $memcached->addServer(getenv('MEMCACHED_HOST') ?: 'memcached', (int) (getenv('MEMCACHED_PORT') ?: 11211));
    if (!$memcached->set('yii-dev-healthcheck', 'ok', 10) || $memcached->get('yii-dev-healthcheck') !== 'ok') {
        throw new RuntimeException($memcached->getResultMessage());
    }
    ok('Memcached');
} catch (Throwable $e) {
    fail('Memcached', $e);
}

$selenium = rtrim(getenv('SELENIUM_URL') ?: 'http://selenium:4444', '/') . '/status';
$body = @file_get_contents($selenium);
$status = is_string($body) ? json_decode($body, true) : null;
if (!is_array($status) || (($status['value']['ready'] ?? false) !== true)) {
    fwrite(STDERR, "ERR Selenium: endpoint is not ready at {$selenium}\n");
    exit(1);
}
ok('Selenium');

fwrite(STDOUT, "Environment is ready.\n");
